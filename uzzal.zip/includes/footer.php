    <script src="js/storage.js"></script>
    <script src="js/ui.js"></script>
    <script>
        // Initialize Dark Mode
        UI.initDarkMode();
    </script>
</body>

</html>
